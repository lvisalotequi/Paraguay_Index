# Scraper de noticias del MRE de Paraguay (2015–2025)

Este proyecto descarga noticias públicas del Ministerio de Relaciones Exteriores
de Paraguay, combina el archivo actual con copias históricas de Wayback Machine y
cuenta menciones a Estados Unidos mediante reglas explícitas. **No usa IA**: una
misma copia de las páginas y la misma configuración producen el mismo resultado.

## Qué entrega

En la carpeta de salida crea:

- `noticias_todas.csv`: fecha, mes, título, descripción, texto completo, URLs,
  fuente, estado de extracción y conteo de menciones.
- `noticias_menciones_eeuu.csv`: solo las noticias con al menos una mención.
- `resumen_mensual.csv`: por cada mes de 2015 a 2025, noticias recolectadas,
  noticias que mencionan a EE. UU. y número total de apariciones.
- `manifiesto.json`: parámetros, fecha de ejecución y controles de calidad.
- `cache/`: copia local de cada respuesta para poder reanudar y auditar.

El resultado distingue dos magnitudes que no deben confundirse:

1. `noticias_que_mencionan_eeuu`: cuántas noticias hablan al menos una vez del país.
2. `total_menciones_eeuu`: cuántas apariciones textuales hubo en total.

## Instalación en Windows (PowerShell)

```powershell
cd "C:\ruta\al\proyecto\mre_eeuu_scraper"
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## Prueba rápida

```powershell
.\.venv\Scripts\python.exe -m unittest -v
.\.venv\Scripts\python.exe scraper_mre.py --desde 2024 --hasta 2025 --limite 10 --max-paginas-actual 1 --salida salida_piloto --cache cache
```

## Ejecución completa solicitada

```powershell
.\.venv\Scripts\python.exe scraper_mre.py --desde 2015 --hasta 2025 --salida salida_2015_2025 --cache cache --demora 1.5
```

## Clasificación bilateral

Después de terminar la recolección, ejecute:

```powershell
.\.venv\Scripts\python.exe clasificar_bilateral.py `
  --entrada salida_2015_2025\noticias_todas.csv `
  --salida salida_bilateral_2015_2025
```

Esto genera `noticias_clasificadas.csv` y `resumen_bilateral_mensual.csv`.
Las reglas y umbrales están en `reglas_bilaterales.json`; no se utiliza IA.

Wayback puede tardar varias horas y ocasionalmente limitar solicitudes. La caché
permite volver a ejecutar exactamente el mismo comando sin repetir descargas ya
completadas. `checkpoint.ndjson` conserva cada resultado apenas termina, incluso
si se interrumpe la ejecución. No reduzca demasiado `--demora`.

Opciones útiles:

- `--solo actual` o `--solo wayback`: procesa una sola fuente.
- `--limite 20`: piloto con un máximo de 20 noticias.
- `--max-paginas-actual 2`: limita la paginación del sitio actual.
- `--reintentos 5 --timeout 90`: tolera respuestas lentas.
- `--trabajadores 6`: procesa varias respuestas a la vez, manteniendo la demora
  global configurada entre solicitudes.

## Reglas de mención

Las expresiones están en `terminos_eeuu.json`. Incluyen “Estados Unidos”,
“Estados Unidos de América”, variantes de “EE. UU.”, “USA”, “estadounidense” y
“norteamericano”. No cuentan “Emiratos Árabes Unidos”. Se pueden editar antes de
una corrida; el archivo resultante conserva en `terminos_encontrados` qué forma
activó cada coincidencia.

## Controles y límites metodológicos

- Solo entran al resumen filas con `estado=ok`, fecha dentro del periodo y texto
  suficiente. Los errores permanecen en `noticias_todas.csv` para auditarlos.
- El scraper elimina duplicados por URL canónica y prefiere el sitio actual si la
  misma noticia aparece en ambas fuentes.
- Wayback no garantiza haber archivado todas las páginas. Por eso el conteo mide
  las noticias recuperables, no necesariamente la producción histórica completa.
- Para no perder noticias de diciembre archivadas con retraso, el índice de
  Wayback se consulta hasta el año posterior al final del periodo; luego se filtra
  estrictamente por la fecha de publicación solicitada.
- El conteo es textual y reproducible; todavía no clasifica si la mención es
  diplomática. Esa etapa puede añadirse después con reglas nuevas y versionadas.
- Deben respetarse las condiciones de uso, `robots.txt` y límites de ambos sitios.
